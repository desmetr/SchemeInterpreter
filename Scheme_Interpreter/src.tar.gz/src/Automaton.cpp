/*
 * Automaton.cpp
 *
 *  Created on: Apr 10, 2014
 *      Author: ajay
 */

#include "Automaton.h"

/*
 *  Geen constructor en destructor nodig, initialisatie van attributes in .h file.
 *  Automaton.h heeft alleen maar pure virtual methods
 *  die geen initialisatie/implementatie nodig hebben hier.
 *
 * 	De struct en de klasse hebben alleen maar attributes die gebruikt worden in de subklassen.
 */
